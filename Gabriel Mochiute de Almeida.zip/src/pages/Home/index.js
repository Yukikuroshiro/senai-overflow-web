import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";

import {
  ActionsContainer,
  Container,
  Content,
  FeedContainer,
  Header,
  IconSignOut,
  Logo,
  ProfileContainer,
  QuestionCard,
  AnswersCard,
  AnswersContainer,
} from "./styles";

import imgProfile from "../../assets/foto_perfil.png";
import logo from "../../assets/logo.png";
import { api } from "../../services/api";
import { signOut } from "../../services/security";

function Profile() {
  return (
    <>
      <section>
        <img src={imgProfile} alt="Imagem de perfil" title="Foto de Perfil" />
        <a href="a">Editar Foto</a>
      </section>
      <section>
        <strong>NOME:</strong>
        <p>Fulano de Tal</p>
      </section>
      <section>
        <strong>RA:</strong>
        <p>1234567</p>
      </section>
      <section>
        <strong>E-MAIL:</strong>
        <p>fulano@gmail.com</p>
      </section>
    </>
  );
}

function Question({ question }) {
  const [answer, setAnswer] = useState("");
  const [show, setShow] = useState(true);
  const [visibility, setVisibility] = useState("block");

  const handleInput = (e) => {
    setAnswer(e.target.value);
    console.log(answer);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await api.post(`/questions/${question.id}/answers`, {
        description: answer,
      });

      //reload()

      console.log(response);
    } catch (error) {}
  };

  const showAnswers = () => {
    if (show === true) {
      // const container = question.Answers.map((a) => <Answer answer={a} />);
      // console.log(container);

      setVisibility("none");
      setShow(false);
    } else {
      setVisibility("block");
      setShow(true);
    }

    // alert(show);
  };

  const qtdAnwers = question.Answers.length;

  return (
    <QuestionCard>
      <header>
        <img src={imgProfile} />
        <strong>por {question.Student.name}</strong>
        <p>em {question.created_at}</p>
      </header>
      <section>
        <strong>{question.title}</strong>
        <p>{question.description}</p>
        <img src={question.image} />
      </section>
      <footer>
        <h1 onClick={showAnswers}>
          {qtdAnwers === 0 ? (
            "Seja o primeiro a responder"
          ) : (
            <>
              {qtdAnwers}
              {qtdAnwers > 1 ? " Respostas" : " Resposta"}
            </>
          )}
        </h1>

        <AnswersContainer style={{ display: visibility }}>
          {question.Answers.map((a) => (
            <Answer answer={a} />
          ))}
        </AnswersContainer>
        {/* <AnswersCard>
          <header>
            <img src={imgProfile} />
            <strong>por </strong>
            <p>12/12/2012 as 12:12</p>
          </header>
          <p>Resposta para a pergunta.</p>
        </AnswersCard> */}

        <form onSubmit={handleSubmit}>
          <textarea
            placeholder="Responda essa dúvida!"
            onChange={handleInput}
            required
            id="answer"
          >
            {answer}
          </textarea>
          <button>Enviar</button>
        </form>
      </footer>
    </QuestionCard>
  );
}

function Answer({ answer }) {
  return (
    <AnswersCard>
      <header>
        <img src={imgProfile} />
        <strong>por {answer.Student.name}</strong>
        <p>as {answer.created_at}</p>
      </header>
      <p>{answer.description}</p>
    </AnswersCard>
  );
}

function Home() {
  const history = useHistory();

  const [questions, setQuestions] = useState([]);

  useEffect(() => {
    const loadQuestions = async () => {
      const response = await api.get("/questions/feed");

      setQuestions(response.data);

      console.log(response);
    };

    loadQuestions();
  }, []);

  const handleSignOut = () => {
    signOut();

    history.replace("/");
  };

  return (
    <Container>
      <Header>
        <Logo src={logo} />
        <IconSignOut onClick={handleSignOut} />
      </Header>
      <Content>
        <ProfileContainer>
          <Profile />
        </ProfileContainer>
        <FeedContainer>
          {questions.map((q) => (
            <Question question={q} />
          ))}
        </FeedContainer>
        <ActionsContainer>
          <button>Fazer uma pergunta</button>
        </ActionsContainer>
      </Content>
    </Container>
  );
}

export default Home;
